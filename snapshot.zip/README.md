# graphql-typeorm

[![NPM](https://img.shields.io/npm/v/graphq-typeorm.svg)](https://www.npmjs.com/package/graphql-typeorm)
[![Build Status](https://travis-ci.org/lucianlature/graphql-typeorm.svg?branch=master)](https://travis-ci.org/lucianlature/graphql-typeorm)
[![Coverage](https://codecov.io/gh/lucianlature/graphql-typeorm/branch/master/graph/badge.svg)](https://codecov.io/gh/lucianlature/graphql-typeorm)

GraphQL for MySQL &amp; Postgres via TypeORM

# Alpha version to be released soon!